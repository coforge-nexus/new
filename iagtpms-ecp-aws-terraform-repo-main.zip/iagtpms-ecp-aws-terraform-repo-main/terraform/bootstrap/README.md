# Bootstrapping Terraform
This is a bootstrap terraform subdirectory which creates the following:

- The terraform state resources (S3 and DynamoDB Table)
- The IAM role used to deploy terraform via Github Actions
- The Github OpenID Connect (OIDC) provider used to integrate Github to AWS to assume role to the above IAM role.

## Bootstrapping account/environment
This will create all the underlying resources needed before terraform resources can be deployed using terraform plans/applies via github actions. Terraform states are stored in a remote backend (e.g. s3) to work collabroatively in teams but to avoid the chicken-and-egg scenario the bootstrapping module will deploy the resources and store the state locally. The state can be migrated to an s3 bucket created in the bootstrap module or stored in github (not recommended for production scenarios). More info on states [here](https://developer.hashicorp.com/terraform/language/state). 

This module is intended to be used with terraform workspaces to separate environment terraform states. More info on workspaces [here](https://developer.hashicorp.com/terraform/language/state/workspaces). 

Authenticating to your AWS enviroment using Terraform can be done through the AWS Provider. More info on the several authentication methods [here](https://registry.terraform.io/providers/hashicorp/aws/latest/docs).

### Bootstrapping process
1. `cd` into bootstrap directory
2. Select terraform workspace (e.g: `terraform workspace select dev`). If the workspace doesn't exist, create a new one: `terraform workspace new dev`
3. Run `terraform init` this will initialize the directory
4. Run `terraform plan` this will plan your changes so you can see them in advance
5. Run `terraform apply` to apply these changes.

Account should now be ready to be used for github actions.

# Overview
This module is designed to facilitate the creation of AWS IAM roles and a OpenID Connect (OIDC) provider to enable Github Actions workflows to interact securely with AWS resources. 

### Features

- **AWS IAM Role Creation**: 
Automatically setup IAM roles for different GitHub Actions environments.
- **OIDC Provider Setup**: 
Configures an AWS OIDC provider for GitHub, allowing for secure, token-based authentication from GitHub Actions.

### Prerequisites
- **AWS Account**: 
Ensure you have access to the AWS account where resources will be created.
- **Terraform**: 
You should have Terraform installed locally to manage and apply this module.
- **Task**: 
This project uses Task to simplify Terraform commands.
- **AWS CLI**: 
Required for AWS operations, including SSO login.
- **TFLint**: 
Optional but recommended for linting Terraform files.

### Files and Directories

**main.tf**: The main Terraform file containing the module logic.
**variables.tf**: Defines input variables for the module.
**taskfile.yml**: Contains Task commands to manage Terraform operations.
**deploy/sandbox_01/backend-sandbox-01.conf**: Backend configuration for Terraform in a specific AWS environment.
**modules/github_oidc_aws**: The Terraform module directory.

### Usage:

**AWS SSO Authentication**:

```bash
task aws:sandbox-01
```
Replace sandbox-01 with your AWS Profile

**Terraform Initialization**:

Navigate to the directory where you want to deploy the module and run:
```bash
task tf:init
```
**Create OIDC Provider and Roles**:

Use the provided child module example to create the OIDC provider and roles in your Terraform configuration:

```hcl
module "github_oidc_aws" {
  source                   = "./modules/github_oidc_aws"
  repository_name          = "<your-repository-name>"
  state_lock_table_name   = "<your-dynamo-table-name>"
  provider_already_created = "<true or false>"
}
```

Replace with your right inputs

### Local Development

**Formatting**: To format Terraform files, run:
```bash
task tf:fmt
```
**Planning:** To create a Terraform plan, run:
```bash
task tf:plan
```
**Applying**: To apply Terraform changes, run:
```bash
task tf:apply
```

From the outputs you can then grab your role ARN to use in the GitHub Actions pipeline.
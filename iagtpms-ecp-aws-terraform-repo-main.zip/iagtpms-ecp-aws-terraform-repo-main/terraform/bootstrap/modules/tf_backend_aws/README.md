# Overview
This Terraform module is designed to streamline the setup of an AWS backend for new Terraform projects. It automates the creation of an Amazon S3 bucket for state storage and an Amazon DynamoDB table for state locking.

### Features
**S3 Bucket Creation**: Sets up an S3 bucket for storing Terraform state files, ensuring they are maintained in a centralized and secure location.
**DynamoDB Table for State Locking**: Creates a DynamoDB table to handle state locking, preventing conflicts during concurrent Terraform operations.
**Versioning**: Enables versioning on the S3 bucket to keep a history of state changes.


### Prerequisites
**AWS Account**: Access to an AWS account where resources will be created.
**Terraform**: Terraform installed on your local machine.
**AWS CLI**: Authenticate to AWS via CLI
```bash
aws sso login --profile <your-profile-name>
```

### Module Files
**main.tf (in module tf_backend_aws)**: Contains the primary logic for creating the S3 bucket and DynamoDB table.
**variables.tf**: Defines input variables for customizing the DynamoDB table and S3 bucket names.
**outputs.tf**: Provides output information about the created resources.

### Usage
**Setting Up the Backend**
**Define the Module**: In your Terraform configuration, declare the module and provide values for required variables:
```hcl
module "tf_backend_aws" {
  source              = "./modules/tf_backend_aws"
  dynamodb_table_name = "ccoe-ecp-cicd-lockfile-tfstate"
  s3_bucket_name      = "ccoe-ecp-cicd-tfstate"
}
```
Replace the values for dynamodb_table_name and s3_bucket_name as needed.

**Initialize Terraform**:
Run terraform init to initialize your Terraform workspace.

**Apply the Configuration**:
Execute terraform apply to create the backend resources.

**Post-Configuration**
After applying the module, your Terraform state will still be stored locally. To migrate your state to the newly created S3 backend:

**Configure Terraform Backend**: Update your Terraform configuration to use the newly created S3 bucket and DynamoDB table as a backend. Example backend configuration:
```hcl
terraform {
  backend "s3" {
    bucket         = "<s3_bucket_name_from_output>"
    key            = "path/to/your/terraform.tfstate"
    region         = "eu-west-1"
    dynamodb_table = "<dynamodb_table_name_from_output>"
    encrypt        = true
  }
}
```
**Reinitialize Terraform**: Run terraform init again. Terraform will detect the change in backend configuration and prompt you to migrate your existing state to the new S3 bucket.

### Important Notes

#### Security: 
Ensure your AWS credentials are securely managed and have the necessary permissions to create these resources.
#### Naming Conventions: 
The S3 bucket name is suffixed with the AWS account ID to help ensure uniqueness.
#### Versioning and Locking: 
These features are critical for maintaining the integrity of your Terraform state, especially in team environments.

By using this module, you can quickly set up a robust and secure backend for managing Terraform state in AWS, suitable for both individual and collaborative Terraform projects.
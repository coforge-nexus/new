# IAG-CCOE-CICD-Templates

## Introduction
The Enterprise Cloud Platform (ecp) CI/CD pipeline creation service, enables team to get a preconfigured continuous delivery pipelines configured using a preapproved pattern from their chosen GitHub repository to their AWS account. This empowers developers with a seamless and efficient workflow for software and infrastructure development by encouraging development in a DEVSECOPS manner.  

This services enables teams to automate the process of building, testing, and deploying code by providing a consistent pipeline, which once deployed they are able to modify to suit their needs. Developers can push changes to GitHub, triggering automatic testing and deployment to AWS infrastructure. By streamlining the development process, CI/CD pipelines reduce human error, enhance scalability, and help teams to ensure that infrastructure as code can be used.  

Teams new to DEVSECOPS or cloud more generally struggle with the setting up CI/CD pipelines. This service will deploy an agreed pattern of a CI/CD pipeline, specifically for that application service, between a github repo and an aws account.

## Tech Stack

**IaC:**
- Terraform (https://www.terraform.io/downloads)
- Terraform-docs (https://terraform-docs.io)
- TFLint (https://github.com/terraform-linters/tflint)

**CI/CD:** GitHub Actions

**Toolchain:**
- Taskfile (https://taskfile.dev)
- AWS SSO (https://docs.aws.amazon.com/cli/latest/userguide/sso-configure-profile-token.html)
- GitHub CLI (https://github.com/cli/cli#installation)
- AWS CLI (https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)

## Run Locally

Clone the project

```bash
  git clone https://github.com/IAG-Ent/IAG-CCOE-CICD-Template.git
```

### Install dependencies

Mac / Linux (using Homebrew):
```bash
  brew install go-task/tap/go-task
```

Login to iag-${env} account for Terraform
```bash
  task aws:${env}
```

Run a Terraform init
```bash
  task tf:init
```

Run a Terraform plan (or apply)
```bash
  task tf:plan -- -var-file=../deploy/${env}/${env}.tfvars
```

### Guidelines for Local Testing

**Local Development Only**
The Taskfile is intended for local testing and development. It's a great way to quickly test and iterate on your Terraform configurations without impacting live environments.

### Applying Changes
**Do not use the Taskfile to apply changes to live environments.** For applying changes, rely on the established GitHub Actions pipeline. This ensures that:

- All changes undergo the necessary review and testing processes.
- There's a clear audit trail and record of all modifications made to the infrastructure.

## GitHub Actions 
GitHub Actions have been configured in the .github/worklows folder, these workflows are responsible for deploying code packages as well as AWS Infrastructure. These serve as examples for how to deploy Infrastructure and Code for your actual application.

All of the workflows deploy sequentially to 3 sets of environments Dev > Test > Prod which all have dedicated environment files in the configs folder. 

Workflows:
- java-deploy - this packages a java app and bundles it to S3
- python-deploy - this packages a python app and bundles it to S3
- ba-java-deploy - (for the BA TEAM)this packages a java app and bundles it to S3 and includes SonarCloud and Snyk scans
- ba-python-deploy - (for the BA TEAM) this packages a python app and bundles it to S3 and includes SonarCloud and Snyk scans
- terraform-deploy - this deploys terraform infrastructure defined in terraform/examples/infra. It uses Trivy scanning before deploying 
- ba-terraform-deploy - (for the BA TEAM) this again deploys terraform infrastructure defined in terraform/examples/infra except it uses SonarCloud and Synk for pre-deploment scanning 

